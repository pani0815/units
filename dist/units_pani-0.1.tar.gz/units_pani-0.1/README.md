Use:

Value * Unit = Value in Base unit
Value / Unit = Value in specified unit

Examples:

val = 5*ms  | val = 0.005
5*inch      | val = 0.0245...cm
